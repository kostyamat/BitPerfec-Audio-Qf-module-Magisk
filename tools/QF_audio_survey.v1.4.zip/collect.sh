#!/system/bin/sh
#
# QF audio survey — reads this head unit's audio configuration and writes it to
# internal storage. It plays nothing and sends nothing by itself; the owner decides whether to pass the
# folder on. The one thing it touches: during the microphone check it switches the audio HAL's own
# capture dump on for ~10 s and back off (v1.4).
#
# 🔴 Everything is written to /data/local/tmp first and copied to /sdcard at the
# end, as a whole directory. Writing straight to /sdcard from a root script
# produces FILES OF ZERO LENGTH on some builds: the data goes to the lower
# filesystem while the FUSE layer the user sees keeps an empty inode. That is
# not theoretical - the first report ever collected came back with every single
# file at 0 bytes, on hardware where it mattered most.

WORK=/data/local/tmp/qf_survey_work
OUT_BASE=/sdcard/QF_audio_survey
STAMP=$(date '+%Y%m%d_%H%M%S')
OUT="$WORK/$STAMP"

rm -rf "$WORK" 2>/dev/null
mkdir -p "$OUT" 2>/dev/null

MODPATH=${0%/*}
say() {
    [ -f "$MODPATH/module.prop" ] && \
        sed -i "s|^description=.*|description=$1|" "$MODPATH/module.prop" 2>/dev/null
    echo "[$(date '+%H:%M:%S')] $1" >> "$OUT/00_progress.txt"
}

# Copy what we have so far to the user's storage. Called more than once, so a
# partial result survives even if the unit is switched off mid-way.
publish() {
    mkdir -p "$OUT_BASE" 2>/dev/null
    cp -r "$OUT" "$OUT_BASE/" 2>/dev/null
    chmod -R 0777 "$OUT_BASE" 2>/dev/null
    # Prove the copy actually carried data, rather than trusting it.
    SRC_BYTES=$(du -s "$OUT" 2>/dev/null | awk '{print $1}')
    DST_BYTES=$(du -s "$OUT_BASE/$STAMP" 2>/dev/null | awk '{print $1}')
    echo "publish: source ${SRC_BYTES}k -> destination ${DST_BYTES}k" >> "$OUT/00_progress.txt"
}

# ---------------------------------------------------------------- identity ---
{
    echo "# what this unit is"
    for p in \
        persist.sys.qf.mcu.version persist.sys.qf.arm.use.i2s \
        persist.sys.qf.radio.ext persist.sys.qf.use.a2dp_route \
        persist.sys.qf.product.name \
        persist.qf.arm.default.volume persist.sys.main_volume \
        persist.sys.navi_volume persist.sys.navi_remix persist.sys.navi_remix_ratio \
        persist.sys.navi_state persist.sys.mainmic.gain persist.sys.secondmic.gain \
        ro.product.model ro.product.device ro.build.display.id ro.board.platform
    do
        echo "$p = [$(getprop $p)]"
    done

    HW=$(getprop persist.sys.qf.mcu.version | awk -F'.' '{print $NF}')
    echo
    echo "# decoded from the suffix ($HW)"
    case "$(echo "$HW" | cut -c2)" in
        0) echo "sound processor = BU32107" ;;
        1) echo "sound processor = BD37534" ;;
        2) echo "sound processor = AK7738" ;;
        3) echo "sound processor = AK7604" ;;
        *) echo "sound processor = unknown" ;;
    esac
    case "$(echo "$HW" | cut -c3)" in
        0) echo "tuner = Build-in" ;;     1) echo "tuner = TSC4745" ;;
        2) echo "tuner = TDA7708" ;;      3) echo "tuner = QN8035" ;;
        4) echo "tuner = TEF6686(NXP)" ;; 5) echo "tuner = TDA7708L" ;;
        6) echo "tuner = TDA7708LX" ;;    7) echo "tuner = LXH4745" ;;
        8) echo "tuner = TDA7786" ;;      9) echo "tuner = SI4755" ;;
        *) echo "tuner = unknown" ;;
    esac
    case "$(echo "$HW" | cut -c4)" in
        0) echo "output path = analogue (SC2730 DAC)" ;;
        *) echo "output path = I2S" ;;
    esac
} > "$OUT/01_identity.txt" 2>&1

getprop > "$OUT/02_getprop_all.txt" 2>&1
say "[1/6] identity collected"

# ------------------------------------------------------- factory audio xml ---
mkdir -p "$OUT/03_vendor_etc" 2>/dev/null
for f in audio_pcm.xml audio_route.xml audio_config.xml audio_effects.xml \
         qf_audio_route_has_i2s.xml qf_audio_route_no_i2s.xml \
         qf_double_bt_audio_route_i2s.xml qf_double_bt_audio_route_noi2s.xml \
         audio_policy_engine_product_strategies.xml \
         audio_policy_engine_stream_volumes.xml audio_policy_volumes.xml \
         primary_audio_policy_configuration.xml audio_policy_configuration.xml
do
    [ -f "/vendor/etc/$f" ] && cp "/vendor/etc/$f" "$OUT/03_vendor_etc/" 2>/dev/null
done
cp /system/config/NaviApp.ini "$OUT/03_vendor_etc/" 2>/dev/null

# The AGDSP parameter files run to megabytes and are the same across the fleet;
# checksums answer "are these standard?" without making the archive unsendable.
md5sum /vendor/etc/audio_params/sprd/*.xml > "$OUT/03_vendor_etc/audio_params_md5.txt" 2>&1
say "[2/6] audio configuration copied"

# ------------------------------------------------------------ sound cards ---
{
    echo "# cards";  cat /proc/asound/cards 2>&1
    echo; echo "# pcm devices"; cat /proc/asound/pcm 2>&1
    echo; echo "# codecs registered"; cat /sys/kernel/debug/asoc/codecs 2>&1
    echo; echo "# i2c devices"; ls -la /sys/bus/i2c/devices/ 2>&1
    echo; echo "# mixer controls"; tinymix 2>&1
} > "$OUT/04_sound_hardware.txt" 2>&1

# The AK hub driver binds on every unit; only the bus says whether a chip is
# really there. XX means the read failed, i.e. nothing answered.
{
    for d in /sys/kernel/debug/regmap/*-001c; do
        [ -d "$d" ] || continue
        echo "regmap: $d"
        echo "name:       $(cat $d/name 2>&1)"
        echo "cache_only: $(cat $d/cache_only 2>&1)"
        echo "-- first registers (XX = chip did not answer) --"
        head -8 "$d/registers" 2>&1
    done
} > "$OUT/05_ak_hub.txt" 2>&1

dumpsys media.audio_policy > "$OUT/06_audio_policy.txt" 2>&1
{
    echo "# is a module installed?"; ls -la /data/adb/modules/ 2>&1
    echo; cat /data/adb/modules/BitPerfect.module/module.prop 2>&1
    echo; echo "# module log"; tail -60 /data/adb/BitPerfect.log 2>&1
} > "$OUT/07_modules.txt" 2>&1
# v1.3: which navigators are installed and how the unit is told about them - the navigator is what
# people complain about first, and every one of them announces itself differently.
{
    echo "# installed navigation / map apps (uid = the number in the audio dumps)"
    pm list packages -U 2>/dev/null | grep -iE 'navi|map|waze|sygic|igo|osmand|here|tomtom|navitel|2gis|yandex|organic|garmin|copilot|progorod|cityguide|gps|route|mapy|petal' | sort
    echo
    echo "# versions"
    for p in $(pm list packages 2>/dev/null | sed 's/^package://' | grep -iE 'navi|map|waze|sygic|igo|osmand|here|tomtom|navitel|2gis|yandex|organic|garmin|copilot|progorod|cityguide|gps|route|mapy|petal'); do
        echo "$p $(dumpsys package "$p" 2>/dev/null | grep -E 'versionName=' | sed 's/^ *//' | tr '\n' ' ')"
    done
    echo
    echo "# navigation properties"; getprop 2>/dev/null | grep -i navi
    echo
    echo "# navigation settings"
    for ns in system secure global; do settings list $ns 2>/dev/null | grep -i navi | sed "s/^/$ns: /"; done
} > "$OUT/11_navigators.txt" 2>&1
say "[3/6] hardware and policies read"

publish        # a usable report exists from here on, even if nothing else happens

# --------------------------------------------------------- a volume snapshot --
snapshot() {
    LABEL=$1
    {
        echo "===== $LABEL   $(date '+%H:%M:%S') ====="
        echo "-- volumes --"
        for p in sys.current.vol.type sys.media.vol sys.radio.vol sys.aux.vol \
                 sys.bt.vol sys.navi.vol persist.sys.navi_state \
                 persist.qf.arm.default.volume persist.sys.main_volume
        do
            echo "  $p = [$(getprop $p)]"
        done
        echo "  STREAM_MUSIC  = $(media volume --stream 3 --get 2>/dev/null | grep 'volume is')"
        echo "  STREAM_SYSTEM = $(media volume --stream 1 --get 2>/dev/null | grep 'volume is')"
        echo "-- active playback --"
        for s in /proc/asound/card0/pcm*p/sub0; do
            ST=$(head -1 "$s/status" 2>/dev/null)
            case "$ST" in
                *RUNNING*)
                    echo "  $s: $ST"
                    sed 's/^/     /' "$s/hw_params" 2>/dev/null
                    ;;
            esac
        done
        echo "-- I2S width --"
        echo "  $(tinymix 'VBC_IIS_MST_WIDTH_SET' 2>/dev/null | tail -1)"
        echo "-- who is playing --"
        dumpsys media_session 2>/dev/null | sed -n '/Audio playback/,/^$/p'
        echo "-- audio focus (last = top) and started players --"
        dumpsys audio 2>/dev/null > "$WORK/da_snap.txt"
        sed -n '/Audio Focus stack entries/,/^$/p' "$WORK/da_snap.txt"
        sed -n '/^  players:/,/^$/p' "$WORK/da_snap.txt" | grep 'state:started'
    } >> "$OUT/08_navigation_event.txt" 2>&1
}

# ------------------------------------------ wait for a navigation prompt ------
say "[4/6] READY. Please play music/radio, start your navigator and let it speak once."
snapshot "BEFORE - baseline, nothing speaking yet"

# v1.3: a prompt is recognised by what EVERY navigator does, not by one usage value. While it speaks
# a navigator holds TRANSIENT audio focus (music holds plain GAIN; UI clicks take no focus at all), or
# it plays with a navigation/assistant usage - some navigators speak as ASSISTANT, not as NAVIGATION.
nav_speaking() {
    [ "$(getprop persist.sys.navi_state)" = "true" ] && return 0
    dumpsys audio 2>/dev/null > "$WORK/da_poll.txt"
    sed -n '/Audio Focus stack entries/,/^$/p' "$WORK/da_poll.txt" | grep -q 'gain: GAIN_TRANSIENT' && return 0
    sed -n '/^  players:/,/^$/p' "$WORK/da_poll.txt" | grep 'state:started'         | grep -qE 'usage=USAGE_(ASSISTANCE_NAVIGATION_GUIDANCE|ASSISTANT)' && return 0
    return 1
}

CAUGHT=""
N=0
while [ $N -lt 900 ]; do          # up to ~7 minutes
    if nav_speaking; then
        cp "$WORK/da_poll.txt" "$OUT/12_dumpsys_audio_during.txt" 2>/dev/null
        snapshot "DURING - a navigation prompt is speaking"
        # v1.2: what the HAL is fed (format, rate, track gain). Written to a FILE in full: a dumpsys of
        # audio_flinger cut short by a pipe (head, grep -m) can take the audio HAL down.
        dumpsys media.audio_flinger > "$OUT/10_audio_flinger_during.txt" 2>&1
        dumpsys media.audio_policy > "$OUT/13_audio_policy_during.txt" 2>&1
        sleep 1
        snapshot "DURING+1s"
        CAUGHT=yes
        sleep 4
        snapshot "AFTER - prompt finished"
        break
    fi
    N=$((N + 1))
    sleep 0.5
done

if [ -z "$CAUGHT" ]; then
    snapshot "TIMEOUT - no navigation prompt was heard"
fi
dumpsys media.audio_flinger > "$OUT/10_audio_flinger.txt" 2>&1

# ------------------------------------------------- v1.4: microphone check -----
# What a recorder really receives. While someone records (wDSP's raw input = source 9, an assistant =
# source 6) the survey notes which source and which input mode the HAL chose. On UIS8581 the HAL can also
# save the capture at two points - before its processing (noprocess) and after its noise reduction
# (afternr) - so the two files answer "is the 'unprocessed' input really untouched": identical = yes.
# The dump is switched on only while a recording is running, for about 10 s, then off again; the
# previous value of persist.vendor.media.dump.switch is put back.
capture_running() {
    for s in /proc/asound/card*/pcm*c/sub0/status; do
        grep -q RUNNING "$s" 2>/dev/null && return 0
    done
    return 1
}
fifo_send() {   # a FIFO write blocks without a reader - never let it hang the survey
    timeout 3 sh -c "echo '$1' > '$MIC_FIFO'" 2>/dev/null
}

MIC="$OUT/14_microphone"
mkdir -p "$MIC" 2>/dev/null
HALF=$(ls /vendor/lib/hw/audio.primary.*.so /vendor/lib64/hw/audio.primary.*.so 2>/dev/null | grep -v default | head -1)
MIC_FIFO=/data/vendor/local/media/mmi.audio.ctrl
[ -p "$MIC_FIFO" ] || MIC_FIFO=/dev/pipe/mmi.audio.ctrl
MIC_DUMPS=no
grep -q "audio_dumpinread_afternr" "$HALF" 2>/dev/null && [ -p "$MIC_FIFO" ] && MIC_DUMPS=yes
echo "hal=$HALF fifo=$MIC_FIFO two-point dumps=$MIC_DUMPS" > "$MIC/00_what.txt"

say "[5/6] MICROPHONE: open wDSP and start its microphone (or any voice recorder) for about 15 seconds - talk near the mic."
REC=""
N=0
while [ $N -lt 600 ]; do          # up to ~5 minutes
    if capture_running; then REC=yes; break; fi
    N=$((N + 1))
    sleep 0.5
done

if [ -n "$REC" ]; then
    dumpsys media.audio_policy > "$MIC/01_audio_policy_recording.txt" 2>&1
    dumpsys media.audio_flinger > "$MIC/02_audio_flinger_recording.txt" 2>&1
    for s in /proc/asound/card*/pcm*c/sub0; do
        grep -q RUNNING "$s/status" 2>/dev/null || continue
        { echo "=== $s"; cat "$s/status"; cat "$s/hw_params"; } >> "$MIC/03_capture_pcm.txt" 2>&1
    done
    if [ "$MIC_DUMPS" = "yes" ]; then
        OLD_SW=$(getprop persist.vendor.media.dump.switch)
        for p in noprocess afternr aftersrc; do
            rm -f "/data/vendor/local/media/audio_dumpinread_$p.wav" "/data/vendor/local/media/audio_dumpinread_$p.pcm"
        done
        rm -f /data/vendor/local/media/audio_dumpinread.wav /data/vendor/local/media/audio_dumpinread.pcm
        fifo_send "media.dump.switch=0xe800"   # inread + aftersrc + noprocess + afternr
        sleep 10
        fifo_send "media.dump.switch=0"
        sleep 2
        if [ -n "$OLD_SW" ]; then
            fifo_send "media.dump.switch=$OLD_SW"
        else
            resetprop -p --delete persist.vendor.media.dump.switch 2>/dev/null
        fi
        for f in /data/vendor/local/media/audio_dumpinread*.wav /data/vendor/local/media/audio_dumpinread*.pcm; do
            [ -f "$f" ] || continue
            SZ=$(stat -c %s "$f" 2>/dev/null)
            [ "${SZ:-0}" -le 31457280 ] && cp "$f" "$MIC/" 2>/dev/null
            rm -f "$f"
        done
        {
            echo "# sizes and md5 of the HAL's capture dumps"
            ls -la "$MIC"/audio_dumpinread* 2>&1
            md5sum "$MIC"/audio_dumpinread* 2>&1
            echo
            for ext in wav pcm; do
                A="$MIC/audio_dumpinread_noprocess.$ext"; B="$MIC/audio_dumpinread_afternr.$ext"
                [ -f "$A" ] && [ -f "$B" ] || continue
                if cmp -s "$A" "$B"; then
                    echo "VERDICT ($ext): before-processing and after-noise-reduction are IDENTICAL - the input is untouched"
                else
                    echo "VERDICT ($ext): before-processing and after-noise-reduction DIFFER - the HAL processes this input"
                fi
            done
        } > "$MIC/04_verdict.txt" 2>&1
    fi
    sleep 3
    logcat -d -b main 2>/dev/null | grep -iE "unprocess|NV mode|check_support_nr|AudioRecordNr|init_rec_process|InMode|input_source|in_set_parameters|audio_record_nr|dump switch|dump point" | tail -300 > "$MIC/05_hal_record_log.txt"
    say "[5/6] microphone recorded and checked"
else
    echo "no recording was started within 5 minutes" > "$MIC/04_verdict.txt"
fi
publish

{
    for s in /proc/asound/card0/pcm*p/sub0 /proc/asound/card0/pcm*c/sub0; do
        echo "=== $s ==="; cat "$s/status" 2>&1
        echo "--- hw_params ---"; cat "$s/hw_params" 2>&1; echo
    done
} > "$OUT/09_all_pcm.txt" 2>&1

publish

if [ -n "$CAUGHT" ]; then
    say "[6/6] DONE - navigation prompt captured. Please zip /sdcard/QF_audio_survey and send it."
else
    say "[6/6] DONE (partial) - no navigation prompt in 7 minutes. Everything else was collected."
fi

publish
rm -rf "$WORK" 2>/dev/null
