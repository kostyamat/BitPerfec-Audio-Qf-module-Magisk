##########################################################################
# QF Audio Survey — read-only collector
##########################################################################
: "${MODPATH:=${0%/*}}"

ui_print " "
ui_print "***************************************************"
ui_print "   QF Audio Survey  -  read only, changes nothing   "
ui_print "***************************************************"
ui_print " "
ui_print "  This module does NOT change your sound, your"
ui_print "  settings or your system, and it sends nothing"
ui_print "  anywhere. It reads the audio configuration and"
ui_print "  writes it to:"
ui_print " "
ui_print "      /sdcard/QF_audio_survey/"
ui_print " "
ui_print "  You decide whether to send that folder."
ui_print " "
ui_print "  ---------------------------------------------"
ui_print "  AFTER REBOOTING, please do this ONCE:"
ui_print " "
ui_print "    1. start music or the radio"
ui_print "    2. start your navigator"
ui_print "    3. let it speak one prompt over the music"
ui_print " "
ui_print "  That single prompt is what the survey is for -"
ui_print "  it shows how your unit mixes navigation with"
ui_print "  music, which differs from unit to unit."
ui_print "  ---------------------------------------------"
ui_print " "
ui_print "  Watch this module in the Magisk app: its"
ui_print "  description shows the progress and says DONE."
ui_print "  Then you can uninstall it."
ui_print " "

MCU=$(getprop persist.sys.qf.mcu.version)
HW=$(echo "$MCU" | awk -F'.' '{print $NF}')
ui_print "- MCU version : ${MCU:-unknown}"
if [ -n "$HW" ]; then
    case "$(echo "$HW" | cut -c2)" in
        0) ui_print "- Sound chip  : BU32107" ;;
        1) ui_print "- Sound chip  : BD37534" ;;
        2) ui_print "- Sound chip  : AK7738" ;;
        3) ui_print "- Sound chip  : AK7604" ;;
        *) ui_print "- Sound chip  : unknown" ;;
    esac
    case "$(echo "$HW" | cut -c4)" in
        0) ui_print "- Output path : analogue (SC2730 DAC)" ;;
        *) ui_print "- Output path : I2S" ;;
    esac
fi
ui_print "- I2S flag    : $(getprop persist.sys.qf.arm.use.i2s)"
ui_print "- Double BT   : $(getprop persist.sys.qf.use.a2dp_route)"
ui_print " "

set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/collect.sh" 0 0 0755

ui_print "- Installed. Reboot, then follow the three steps above."
ui_print " "
