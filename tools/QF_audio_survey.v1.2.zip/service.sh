#!/system/bin/sh
#
# Runs the survey once, after boot, then stays out of the way on later boots.
# Everything it reports goes into the module's own description, so the owner can
# follow it in the Magisk app without a terminal and without adb.

MODPATH=${0%/*}
MARKER="$MODPATH/.collected"

[ -f "$MARKER" ] && exit 0

(
    N=0
    while [ "$(getprop sys.boot_completed)" != "1" ] && [ $N -lt 180 ]; do
        sleep 1
        N=$((N + 1))
    done
    sleep 10

    sh "$MODPATH/collect.sh" > /dev/null 2>&1

    RESULT=$(ls -d /sdcard/QF_audio_survey/*/ 2>/dev/null | tail -1)
    if [ -n "$RESULT" ]; then
        touch "$MARKER"
    else
        sed -i "s|^description=.*|description=[FAILED] Nothing was written. Please tell the developer.|" \
            "$MODPATH/module.prop" 2>/dev/null
    fi
) &
