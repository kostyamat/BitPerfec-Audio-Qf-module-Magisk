#!/system/bin/sh
#
# QF audio survey — reads this head unit's audio configuration and writes it to
# internal storage. It changes nothing, plays nothing, and sends nothing by
# itself; the owner decides whether to pass the folder on.
#
# 🔴 Everything is written to /data/local/tmp first and copied to /sdcard at the
# end, as a whole directory. Writing straight to /sdcard from a root script
# produces FILES OF ZERO LENGTH on some builds: the data goes to the lower
# filesystem while the FUSE layer the user sees keeps an empty inode. That is
# not theoretical - the first report ever collected came back with every single
# file at 0 bytes, on hardware where it mattered most.

WORK=/data/local/tmp/qf_survey_work
OUT_BASE=/sdcard/QF_audio_survey
STAMP=$(date '+%Y%m%d_%H%M%S')
OUT="$WORK/$STAMP"

rm -rf "$WORK" 2>/dev/null
mkdir -p "$OUT" 2>/dev/null

MODPATH=${0%/*}
say() {
    [ -f "$MODPATH/module.prop" ] && \
        sed -i "s|^description=.*|description=$1|" "$MODPATH/module.prop" 2>/dev/null
    echo "[$(date '+%H:%M:%S')] $1" >> "$OUT/00_progress.txt"
}

# Copy what we have so far to the user's storage. Called more than once, so a
# partial result survives even if the unit is switched off mid-way.
publish() {
    mkdir -p "$OUT_BASE" 2>/dev/null
    cp -r "$OUT" "$OUT_BASE/" 2>/dev/null
    chmod -R 0777 "$OUT_BASE" 2>/dev/null
    # Prove the copy actually carried data, rather than trusting it.
    SRC_BYTES=$(du -s "$OUT" 2>/dev/null | awk '{print $1}')
    DST_BYTES=$(du -s "$OUT_BASE/$STAMP" 2>/dev/null | awk '{print $1}')
    echo "publish: source ${SRC_BYTES}k -> destination ${DST_BYTES}k" >> "$OUT/00_progress.txt"
}

# ---------------------------------------------------------------- identity ---
{
    echo "# what this unit is"
    for p in \
        persist.sys.qf.mcu.version persist.sys.qf.arm.use.i2s \
        persist.sys.qf.radio.ext persist.sys.qf.use.a2dp_route \
        persist.sys.qf.product.name \
        persist.qf.arm.default.volume persist.sys.main_volume \
        persist.sys.navi_volume persist.sys.navi_remix persist.sys.navi_remix_ratio \
        persist.sys.navi_state persist.sys.mainmic.gain persist.sys.secondmic.gain \
        ro.product.model ro.product.device ro.build.display.id ro.board.platform
    do
        echo "$p = [$(getprop $p)]"
    done

    HW=$(getprop persist.sys.qf.mcu.version | awk -F'.' '{print $NF}')
    echo
    echo "# decoded from the suffix ($HW)"
    case "$(echo "$HW" | cut -c2)" in
        0) echo "sound processor = BU32107" ;;
        1) echo "sound processor = BD37534" ;;
        2) echo "sound processor = AK7738" ;;
        3) echo "sound processor = AK7604" ;;
        *) echo "sound processor = unknown" ;;
    esac
    case "$(echo "$HW" | cut -c3)" in
        0) echo "tuner = Build-in" ;;     1) echo "tuner = TSC4745" ;;
        2) echo "tuner = TDA7708" ;;      3) echo "tuner = QN8035" ;;
        4) echo "tuner = TEF6686(NXP)" ;; 5) echo "tuner = TDA7708L" ;;
        6) echo "tuner = TDA7708LX" ;;    7) echo "tuner = LXH4745" ;;
        8) echo "tuner = TDA7786" ;;      9) echo "tuner = SI4755" ;;
        *) echo "tuner = unknown" ;;
    esac
    case "$(echo "$HW" | cut -c4)" in
        0) echo "output path = analogue (SC2730 DAC)" ;;
        *) echo "output path = I2S" ;;
    esac
} > "$OUT/01_identity.txt" 2>&1

getprop > "$OUT/02_getprop_all.txt" 2>&1
say "[1/5] identity collected"

# ------------------------------------------------------- factory audio xml ---
mkdir -p "$OUT/03_vendor_etc" 2>/dev/null
for f in audio_pcm.xml audio_route.xml audio_config.xml audio_effects.xml \
         qf_audio_route_has_i2s.xml qf_audio_route_no_i2s.xml \
         qf_double_bt_audio_route_i2s.xml qf_double_bt_audio_route_noi2s.xml \
         audio_policy_engine_product_strategies.xml \
         audio_policy_engine_stream_volumes.xml audio_policy_volumes.xml \
         primary_audio_policy_configuration.xml audio_policy_configuration.xml
do
    [ -f "/vendor/etc/$f" ] && cp "/vendor/etc/$f" "$OUT/03_vendor_etc/" 2>/dev/null
done
cp /system/config/NaviApp.ini "$OUT/03_vendor_etc/" 2>/dev/null

# The AGDSP parameter files run to megabytes and are the same across the fleet;
# checksums answer "are these standard?" without making the archive unsendable.
md5sum /vendor/etc/audio_params/sprd/*.xml > "$OUT/03_vendor_etc/audio_params_md5.txt" 2>&1
say "[2/5] audio configuration copied"

# ------------------------------------------------------------ sound cards ---
{
    echo "# cards";  cat /proc/asound/cards 2>&1
    echo; echo "# pcm devices"; cat /proc/asound/pcm 2>&1
    echo; echo "# codecs registered"; cat /sys/kernel/debug/asoc/codecs 2>&1
    echo; echo "# i2c devices"; ls -la /sys/bus/i2c/devices/ 2>&1
    echo; echo "# mixer controls"; tinymix 2>&1
} > "$OUT/04_sound_hardware.txt" 2>&1

# The AK hub driver binds on every unit; only the bus says whether a chip is
# really there. XX means the read failed, i.e. nothing answered.
{
    for d in /sys/kernel/debug/regmap/*-001c; do
        [ -d "$d" ] || continue
        echo "regmap: $d"
        echo "name:       $(cat $d/name 2>&1)"
        echo "cache_only: $(cat $d/cache_only 2>&1)"
        echo "-- first registers (XX = chip did not answer) --"
        head -8 "$d/registers" 2>&1
    done
} > "$OUT/05_ak_hub.txt" 2>&1

dumpsys media.audio_policy > "$OUT/06_audio_policy.txt" 2>&1
{
    echo "# is a module installed?"; ls -la /data/adb/modules/ 2>&1
    echo; cat /data/adb/modules/BitPerfect.module/module.prop 2>&1
    echo; echo "# module log"; tail -60 /data/adb/BitPerfect.log 2>&1
} > "$OUT/07_modules.txt" 2>&1
say "[3/5] hardware and policies read"

publish        # a usable report exists from here on, even if nothing else happens

# --------------------------------------------------------- a volume snapshot --
snapshot() {
    LABEL=$1
    {
        echo "===== $LABEL   $(date '+%H:%M:%S') ====="
        echo "-- volumes --"
        for p in sys.current.vol.type sys.media.vol sys.radio.vol sys.aux.vol \
                 sys.bt.vol sys.navi.vol persist.sys.navi_state \
                 persist.qf.arm.default.volume persist.sys.main_volume
        do
            echo "  $p = [$(getprop $p)]"
        done
        echo "  STREAM_MUSIC  = $(media volume --stream 3 --get 2>/dev/null | grep 'volume is')"
        echo "  STREAM_SYSTEM = $(media volume --stream 1 --get 2>/dev/null | grep 'volume is')"
        echo "-- active playback --"
        for s in /proc/asound/card0/pcm*p/sub0; do
            ST=$(head -1 "$s/status" 2>/dev/null)
            case "$ST" in
                *RUNNING*)
                    echo "  $s: $ST"
                    sed 's/^/     /' "$s/hw_params" 2>/dev/null
                    ;;
            esac
        done
        echo "-- I2S width --"
        echo "  $(tinymix 'VBC_IIS_MST_WIDTH_SET' 2>/dev/null | tail -1)"
        echo "-- who is playing --"
        dumpsys media_session 2>/dev/null | sed -n '/Audio playback/,/^$/p'
    } >> "$OUT/08_navigation_event.txt" 2>&1
}

# ------------------------------------------ wait for a navigation prompt ------
say "[4/5] READY. Please play music/radio, start your navigator and let it speak once."
snapshot "BEFORE - baseline, nothing speaking yet"

CAUGHT=""
N=0
while [ $N -lt 900 ]; do          # up to ~7 minutes
    NAVI=$(getprop persist.sys.navi_state)
    SYS_ACTIVE=$(dumpsys audio 2>/dev/null | grep -c "usage=USAGE_ASSISTANCE_NAVIGATION_GUIDANCE")
    if [ "$NAVI" = "true" ] || [ "${SYS_ACTIVE:-0}" -gt 0 ]; then
        snapshot "DURING - a navigation prompt is speaking"
        # v1.2: what the HAL is fed (format, rate, track gain). Written to a FILE in full: a dumpsys of
        # audio_flinger cut short by a pipe (head, grep -m) can take the audio HAL down.
        dumpsys media.audio_flinger > "$OUT/10_audio_flinger_during.txt" 2>&1
        sleep 1
        snapshot "DURING+1s"
        CAUGHT=yes
        sleep 4
        snapshot "AFTER - prompt finished"
        break
    fi
    N=$((N + 1))
    sleep 0.5
done

if [ -z "$CAUGHT" ]; then
    snapshot "TIMEOUT - no navigation prompt was heard"
fi
dumpsys media.audio_flinger > "$OUT/10_audio_flinger.txt" 2>&1

{
    for s in /proc/asound/card0/pcm*p/sub0 /proc/asound/card0/pcm*c/sub0; do
        echo "=== $s ==="; cat "$s/status" 2>&1
        echo "--- hw_params ---"; cat "$s/hw_params" 2>&1; echo
    done
} > "$OUT/09_all_pcm.txt" 2>&1

publish

if [ -n "$CAUGHT" ]; then
    say "[5/5] DONE - navigation prompt captured. Please zip /sdcard/QF_audio_survey and send it."
else
    say "[5/5] DONE (partial) - no navigation prompt in 7 minutes. Everything else was collected."
fi

publish
rm -rf "$WORK" 2>/dev/null
